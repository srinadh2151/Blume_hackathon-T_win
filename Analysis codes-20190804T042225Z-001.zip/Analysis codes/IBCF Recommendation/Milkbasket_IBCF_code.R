
# installing libraries
install.packages("dplyr")
install.packages("recommenderlab")
install.packages("tidyr")
library(dplyr)
library(recommenderlab)
library(tidyr)
#read data file
mydata <- read.csv(file.choose(), header=T)
# summary
glimpse(mydata)
# create unique identifier
mydata <- mydata %>% mutate(InNo_Desc= paste(order_id, subcategory_id, sep = ' '))

# Filter out duplicates and drop unique identifier
mydata <- mydata[!duplicated(mydata$InNo_Desc), ] %>% select(-InNo_Desc)

# check new rows of data
nrow(mydata)

# create rating matrix
ratings_matrix <- mydata %>% select(order_id, subcategory_id) %>% mutate(value=1) %>% spread(subcategory_id, value, fill=0) %>% select(-order_id) %>% as.matrix() %>% as("binaryRatingMatrix")

# check matrix
ratings_matrix

# evaluation scheme and model validation
scheme <- ratings_matrix %>% evaluationScheme(method = "cross", k=5, train=0.8, given=-1)
scheme

# set up algorithms and confusion matrix

algorithms <- list("association rules" = list(name = "AR", param = list(supp = 0.01, conf = 0.01)), "random items" = list(name = "RANDOM", param=NULL), "popular items" = list(name = "POPULAR", param = NULL), "item-based CF" = list(name= "IBCF", param= list(k=5)), "user-based CF" = list(name = "UBCF", param = list(method = "Cosine", nn=500)))

results <- evaluate(scheme, algorithms, type = "topNList", n = c(1,3,5,10,15,20))
results

temp <- results$ 'user-based CF' %>% getConfusionMatrix() %>% as.list()
as.data.frame( Reduce("+", temp) / length(temp)) %>% mutate(n=c(1,3,5,10,15,20)) %>% select('n', 'precision', 'recall', 'TPR', 'FPR')

temp1 <- results$ 'item-based CF' %>% getConfusionMatrix() %>% as.list()
as.data.frame( Reduce("+", temp1) / length(temp)) %>% mutate(n=c(1,3,5,10,15,20)) %>% select('n', 'precision', 'recall', 'TPR', 'FPR')

temp2 <- results$ 'association rules' %>% getConfusionMatrix() %>% as.list()
as.data.frame( Reduce("+", temp2) / length(temp)) %>% mutate(n=c(1,3,5,10,15,20)) %>% select('n', 'precision', 'recall', 'TPR', 'FPR')

temp3 <- results$ 'random items' %>% getConfusionMatrix() %>% as.list()
as.data.frame( Reduce("+", temp3) / length(temp)) %>% mutate(n=c(1,3,5,10,15,20)) %>% select('n', 'precision', 'recall', 'TPR', 'FPR')

temp4 <- results$ 'popular items' %>% getConfusionMatrix() %>% as.list()
as.data.frame( Reduce("+", temp4) / length(temp)) %>% mutate(n=c(1,3,5,10,15,20)) %>% select('n', 'precision', 'recall', 'TPR', 'FPR')

## recommender model

recomm <- Recommender(getData(scheme, 'train'), method = "IBCF", param = list(k = 5))
recomm

## save model
saveRDS(recomm, file = "myrecomm.rds")

## restoring model
mymodel <- readRDS(file= "myrecomm.rds")

## cnew product id inputs
new_products <- read.delim(file.choose(), sep = "\t", header=F)
new_products

# class(new_products)
customer_order <- as.vector(t(new_products[1, ]))
customer_order

# create new matrix
new_order_rat_matrix <- mydata %>% select(subcategory_id) %>% unique() %>% mutate(value = as.numeric(subcategory_id %in% customer_order)) %>% spread(key = subcategory_id, value = value) %>% as.matrix() %>% as("binaryRatingMatrix")

pred1 <- predict(mymodel, newdata = new_order_rat_matrix, n = 10)
output <- as(pred1, 'list')
output

## write output file
write.table(output, file = "output.txt", sep = "\t", row.names = FALSE)

